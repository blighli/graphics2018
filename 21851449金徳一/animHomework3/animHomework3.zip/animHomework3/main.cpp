//
//  main.cpp
//  animHomework3
//
//  Created by 金徳一 on 2019/1/7.
//  Copyright © 2019 金徳一. All rights reserved.
//
#include <cmath>
#include "ObjLoader.h"
using namespace std;
//模型路径,mac需设置xcode相对路径

string filePath = "obj2.obj";
bool mouseLeftDown=false;
bool mouseRightDown=false;
bool mouseMiddleDown;
float mouseX=0.0f, mouseY=0.0f;
float cameraDistanceX=0.0f;
float cameraDistanceY=0.0f;
float cameraAngleX=0.0f;
float cameraAngleY=0.0f;
float times = 2.0f;
float x1 = 0.0f, z1 = 10.0f; //视点位置
float x2 = 0.0f, z2 = -1.0f, ag=0.0f; //视点漫游角度相关
float speed=0.5; //视点漫游速度

ObjLoader objModel = ObjLoader(filePath);
static int degree = 90;
static int oldPosY = -1;
static int oldPosX = -1;

//安置光源
void setLightRes() {
    GLfloat lightPosition[] = { 0.0f, 0.0f, 1.0f, 0.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
    
    //光源1
    GLfloat lightAmb1[] = { 1, 1, 1, 1.0 };
    //GLfloat lightDif1[] = { 0.0, 0.2, 0.0, 1 };
    GLfloat lightDif1[] = { 0.1, 0.0, 0.0, 1.0 };
    GLfloat lightSpe1[] = { 0.0, 1, 0.0, 1.0 };
    GLfloat lightPos1[] = { -50.0f, 10, 0, 1 };
    GLfloat lightcolor[] = { 0 , 0 , 0 , 1.0 };
    glLightfv(GL_LIGHT1, GL_COLOR, lightcolor);
    glLightfv(GL_LIGHT1, GL_AMBIENT, lightAmb1);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, lightDif1);
    glLightfv(GL_LIGHT1, GL_SPECULAR, lightSpe1);
    glLightfv(GL_LIGHT1, GL_POSITION, lightPos1);
    //glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 60);
    
    //光源2
    GLfloat lightAmb2[] = { 0, 0, 0, 1.0 };
    //GLfloat lightDif2[] = { 0.2, 0.0, 0.0, 1 };
    GLfloat lightDif2[] = { 1, 1, 1, 1.0 };
    GLfloat lightSpe2[] = { 1, 0.0, 0.0, 1.0 };
    GLfloat lightPos2[] = { 50.0f, 0, 0, 1};
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb2);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDif2);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpe2);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos2);
    glEnable(GL_LIGHTING); //启用光源
    glEnable(GL_LIGHT1);
    glEnable(GL_LIGHT0);
    
}
//茶壶材质
void material1(){
    GLfloat maAmb[] = { 0,0,0.2,1 };
    GLfloat maDif[] = { 1, 1, 1,1 };
    GLfloat maSpe[] = { 1, 1, 1,1 };
    GLfloat maShi[] = { 127 };
    glMaterialfv(GL_FRONT, GL_AMBIENT, maAmb);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, maDif);
    glMaterialfv(GL_FRONT, GL_SPECULAR, maSpe);
    glMaterialfv(GL_FRONT, GL_SHININESS, maShi);
}
//模型材质
void material2(){
    GLfloat maAmb[] = { 0.2,0,0,1 };
    GLfloat maDif[] = { 1, 1, 1,1 };
    GLfloat maSpe[] = { 1, 1, 1,1 };
    GLfloat maShi[] = { 127 };
    glMaterialfv(GL_FRONT, GL_AMBIENT, maAmb);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, maDif);
    glMaterialfv(GL_FRONT, GL_SPECULAR, maSpe);
    glMaterialfv(GL_FRONT, GL_SHININESS, maShi);
}
//初始化
void init() {
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(600, 450);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("animHomework3");
    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);
    setLightRes();
    glEnable(GL_DEPTH_TEST);
}

void display()
{
    //glColor3f(0.0, 1.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    //glPushMatrix();
    
    gluLookAt(x1, 0, z1, x1+x2,0, z1+z2, 0, 1, 0);
    //glPopMatrix();
    glScalef(times, times, times);//缩放
    glTranslatef(cameraDistanceX, cameraDistanceY, -5.0f);
    glRotatef(cameraAngleX, 1, 0, 0);
    glRotatef(cameraAngleY, 0, 1, 0);
    material2();
    objModel.Draw();
    glTranslatef(0.0f, -1.56f, 0.0f);
    material1();
    glutSolidTeapot(3.0f);
    glutSwapBuffers();
    //glFlush();
    
}

void mouseCtrl(int button, int state, int x, int y)
{
    mouseX = x;
    mouseY = y;
    if (button == GLUT_LEFT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            mouseLeftDown = true;
        }
        else if (state == GLUT_UP)
            mouseLeftDown = false;
    }
    
    else if (button == GLUT_RIGHT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            mouseRightDown = true;
        }
        else if (state == GLUT_UP)
            mouseRightDown = false;
    }
    else if (state == GLUT_UP && button == 3)
    {
        times *= 1.1;
    }
    
    else if (state == GLUT_UP && button == 4)
    {
        times *= 0.9;
    }
    glutPostRedisplay();
}
void mouseMotionCtrl(int x, int y)
{
    
    if (mouseLeftDown)
    {
        cameraAngleY += (x - mouseX);
        cameraAngleX += (y - mouseY);
        mouseX = x;
        mouseY = y;
        
    }
    if (mouseRightDown)
    {
        cameraDistanceX+= (x - mouseX)*0.1;
        cameraDistanceY-= (y - mouseY)*0.1;
        mouseX = x;
        mouseY = y;
    }
    glutPostRedisplay();
}

void keyCtrl(int key, int x, int y)
{
    switch (key) {
        case GLUT_KEY_LEFT:
            ag -= 0.05f;
            x2 = sin(ag);
            z2 = -cos(ag);
            break;
        case GLUT_KEY_RIGHT:
            ag += 0.05f;
            x2 = sin(ag);
            z2 = -cos(ag);
            break;
        case GLUT_KEY_DOWN:
            x1 -= x2 * speed;
            z1 -= z2 * speed;
            break;
        case GLUT_KEY_UP:
            x1 += x2 * speed;
            z1 += z2 * speed;
            break;
        case 'w':
            times *= 1.2;
            break;
        case 's':
            times *= 0.8;
            break;
    }
    glutPostRedisplay();
}

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0f, (GLdouble)width / (GLdouble)height, 1.0f, 200.0f);
    glMatrixMode(GL_MODELVIEW);
}

//移动鼠标360观察模型
void moseMove(int button, int state, int x, int y)
{
    if (state == GLUT_DOWN) {
        oldPosX = x; oldPosY = y;
    }
}
void changeViewPoint(int x, int y)
{
    int temp = x - oldPosX;
    degree += temp;
    oldPosX = x;
    oldPosY = y;
}

void myIdle()
{
    glutPostRedisplay();
}

int main(int argc, char* argv[])
{
    glutInit(&argc, argv);
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouseCtrl);
    glutMotionFunc(mouseMotionCtrl);
    glutSpecialFunc(keyCtrl);
    glutIdleFunc(myIdle);
    glutMainLoop();
    return 0;
}
